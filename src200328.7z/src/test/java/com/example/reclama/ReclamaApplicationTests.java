package com.example.reclama;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReclamaApplicationTests {

	@Test
	void contextLoads() {
	}

}
